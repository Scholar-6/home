<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'List', 'woffice' ),
	'description' => __( 'Add a list with some icons', 'woffice' ),
	'tab'         => __( 'Content Elements', 'woffice' ),
	'icon' 		  => 'fa fa-list',
);
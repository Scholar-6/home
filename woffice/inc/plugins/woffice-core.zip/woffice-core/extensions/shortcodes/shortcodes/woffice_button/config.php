<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg['page_builder'] = array(
	'title'       => __( 'Button', 'woffice' ),
	'description' => __( 'A very awesome button', 'woffice' ),
	'tab'         => __( 'Content Elements', 'woffice' ),
);